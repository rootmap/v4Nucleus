<div class="modal fade text-xs-left" id="General_Sale" tabindex="-1" role="dialog" aria-labelledby="myModalLabel35" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
      </button>
      <h3 class="modal-title" id="myModalLabel35"> General Sale</h3>
  </div>
  <form>
    <div class="modal-body">
        <div class="form-group row">
            <label class="col-md-4 label-control" for="projectinput1">
                Product Name
            </label>
            <div class="col-md-8">
                <input type="text" id="projectinput1" class="form-control" placeholder="Product Name" name="gName">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-md-4 label-control" for="projectinput1">
               Sold Price
            </label>
            <div class="col-md-8">
                <input type="number" id="projectinput1" class="form-control" placeholder="Price" name="gPrice">
            </div>
        </div>

        <div class="form-group row">
            <label class="col-md-4 label-control" for="projectinput1">
               Cost Price
            </label>
            <div class="col-md-8">
                <input type="number" id="projectinput1" class="form-control" placeholder="Cost Price" name="CPrice">
            </div>
        </div>

        <div class="form-group row">
          <label class="col-md-4 label-control" for="Description">Description</label>
          <div class="col-md-8">
            <textarea class="form-control" id="title1" rows="3" placeholder="Description" name="gDetail"></textarea>
        </div>
    </div>
    <div class="form-group row">
      <label class="col-md-4 label-control" for="Description">&nbsp;</label>
      <div class="col-md-8">
        <button type="button" class="btn btn-green GAddProductToCart">
            <i class="icon-check2"></i> Add Product
        </button>
    </div>
</div>
</div>
</form>
</div>
</div>
</div>