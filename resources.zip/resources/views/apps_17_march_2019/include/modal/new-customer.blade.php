
<div class="modal fade text-xs-left" id="NewCustomerDash" tabindex="-3" role="dialog" aria-labelledby="myModalLabel35" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                      </button>
                      <h3 class="modal-title" id="myModalLabel35"> Add Customer</h3>
                  </div>
                  <form>
                    <div class="modal-body">
                        <div id="#NewCustomerDashMSG" class="form-group row"></div>
                        <div class="form-group row">
                            <label class="col-md-4 label-control" for="projectinput1">Name</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" value="" placeholder="Customer Name" name="new_customer_name">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-4 label-control" for="projectinput1">Address</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" value=""  name="new_customer_address" placeholder="new_customer_address">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-4 label-control" for="projectinput1">Phone</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" value=""  name="new_customer_phone" placeholder="1-(555)-555-5555">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-4 label-control" for="projectinput1">E-mail</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" value=""  name="new_customer_email" placeholder="Email Address">
                            </div>
                        </div>                                                
                    </div>
                    <div class="form-actions center save-new-customer-parent">
                        <button type="button" class="btn btn-green save-new-customer">
                            <i class="icon-check2"></i> Save Customer
                        </button>
                    </div>
                </form>
            </div>
        </div>
        </div>